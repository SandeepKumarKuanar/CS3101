#include <stdio.h>
#include <string.h>

#define N 5

int main() {
    char contestants[N][20] = {"Dev", "Ankush", "Allu", "Nora", "Tamannah"};
    int active[N] = {1, 1, 1, 1, 1}; 
    int totalScore[N] = {0};
    int roundScore[N];
    int i, j, r;

    // ---------- 3 ROUNDS ----------
    for (r = 1; r <= 3; r++) {
        printf("\n--- ROUND %d ---\n", r);

        for (i = 0; i < N; i++) {
            roundScore[i] = 0;
            if (active[i] == 1) {
                int m, p, t;
                printf("\nEnter scores for %s (Madhuri Prabhu Mithun): ", contestants[i]);
                scanf("%d %d %d", &m, &p, &t);
                roundScore[i] = m + p + t;
                totalScore[i] += roundScore[i];
            }
        }

        // Find lowest scorer among active contestants
        int lowIndex = -1, lowScore = 99999;
        for (i = 0; i < N; i++) {
            if (active[i] == 1 && totalScore[i] < lowScore) {
                lowScore = totalScore[i];
                lowIndex = i;
            }
        }

        // Eliminate
        printf("Eliminated in Round %d: %s\n", r, contestants[lowIndex]);
        active[lowIndex] = 0;
    }

    // ---------- WILD CARD ----------
    printf("\nEnter wildcard entry contestant name: ");
    char wildcard[20];
    scanf("%s", wildcard);

    // Identify finalists (2 survivors)
    int finalists[2], f = 0;
    for (i = 0; i < N; i++) {
        if (active[i] == 1)
            finalists[f++] = i;
    }

    // Find wildcard index
    int wildIndex = -1;
    for (i = 0; i < N; i++) {
        if (strcmp(contestants[i], wildcard) == 0)
            wildIndex = i;
    }

    printf("\n--- FINALE ---\n");

    int final3[3] = {finalists[0], finalists[1], wildIndex};
    int finalScores[3] = {0};

    for (i = 0; i < 3; i++) {
        int m, p, t;
        printf("\nFinale scores for %s (Madhuri Prabhu Mithun): ", contestants[final3[i]]);
        scanf("%d %d %d", &m, &p, &t);
        finalScores[i] = m + p + t;
    }

    // Determine winner, 1st runner-up, 2nd runner-up
    // Sort finalScores descending (simple bubble sort)
    for (i = 0; i < 3; i++) {
        for (j = i + 1; j < 3; j++) {
            if (finalScores[j] > finalScores[i]) {
                int temp = finalScores[i];
                finalScores[i] = finalScores[j];
                finalScores[j] = temp;

                int temp2 = final3[i];
                final3[i] = final3[j];
                final3[j] = temp2;
            }
        }
    }

    printf("\n--- FINAL RESULTS ---\n");
    printf("WINNER: %s\n", contestants[final3[0]]);
    printf("FIRST RUNNER-UP: %s\n", contestants[final3[1]]);
    printf("SECOND RUNNER-UP: %s\n", contestants[final3[2]]);

    return 0;
}

